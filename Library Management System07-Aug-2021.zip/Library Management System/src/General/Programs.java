/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package General;
import java.awt.FileDialog;
import java.awt.Frame;
/**
 *
 * @author Abdul Rehman
 */
public class Programs {
    public void FileChooser(){
//        FileDialog file = new FileDialog((Frame) null);
//        file.set
//        file.setVisible(true);
    }
}
