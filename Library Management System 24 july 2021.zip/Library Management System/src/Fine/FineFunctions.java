/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Fine;
import static LMS.MainForm.con;
import static LMS.MainForm.connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.ResultSet;
/**
 *
 * @author Abdul Rehman
 */
public class FineFunctions {
    PreparedStatement ps;
    protected boolean payFine(String fineId) throws SQLException, ClassNotFoundException{
        connection();
        ps = con.prepareStatement("UPDATE FINE SET `STATUS` = 'Paid', Pay_date = CURRENT_DATE() WHERE id = '"+fineId+"'");
        return !ps.execute();
    }
    
    protected boolean isFinePaid(String fineId){
        try {
            connection();
            ps = con.prepareStatement("SELECT `STATUS` AS S FROM FINE WHERE id = '"+fineId+"'");
            ResultSet rs = ps.executeQuery();
            if (rs.next())
                return (rs.getString("S").toLowerCase().equals("paid"));
        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(FineFunctions.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    public String getGender(String id) {
        String mr = "Mr ", miss = "Miss ", both = "Mr/Miss ";
        try {
            connection();
            ps = con.prepareStatement("SELECT sex FROM STUDENT_DATA WHERE ID = '"+id+"'");
            ResultSet rs = ps.executeQuery();
            if (rs.next()){
                if (rs.getString("sex").toLowerCase().equals("male"))
                    return mr;
                else if (rs.getString("sex").toLowerCase().equals("female"))
                    return miss;
                else
                    return both;
            }else
                return both;
        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(FineFunctions.class.getName()).log(Level.SEVERE, null, ex);
        }
        return both;
    }
    
    public int sumOfRemaningFine(String studentId){
        try {
            connection();
            ps = con.prepareStatement("SELECT SUM(FINE) AS F FROM LMS.FINE\n" +
                    "WHERE student_id = '"+studentId+"' AND \n" +
                    "`status` = 'Unpaid'");
            ResultSet rs = ps.executeQuery();
            if (rs.next())
                return rs.getInt("f");
        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(FineFunctions.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
    }
    
    public boolean doesFineRemain(String studentId){
        try {
            connection();
            ps = con.prepareStatement("SELECT student_id AS F FROM LMS.FINE\n" +
                    "WHERE student_id = '"+studentId+"' AND \n" +
                    "`status` = 'Unpaid'");
            ResultSet rs = ps.executeQuery();
            return rs.next();
        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(FineFunctions.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
//    public static void main(String[] args){
//        System.out.println(new FineFunctions().doesFineRemain("010"));
//    }
}
