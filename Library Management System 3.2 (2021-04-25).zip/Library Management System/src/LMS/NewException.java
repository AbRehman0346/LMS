/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LMS;

/**
 *
 * @author Abdul Rehman
 */
public class NewException extends Exception{
    public NewException(String msg){
        super(msg);
    }
    
}
