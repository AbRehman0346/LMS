/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package LMS;
import javax.swing.ImageIcon;
import java.awt.Image;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
/**
 *
 * @author Abdul Rehman Lashari
 */
public class MainForm extends javax.swing.JFrame {
    public static Connection con;
    PreparedStatement ps;
    /** Creates new form MainForm */
    public MainForm() {
        initComponents();
        //Below Function is for Setting Icons on Front Page
        setIcons();
        
        CreateDatabases();
        
        this.setDefaultCloseOperation(javax.swing.JFrame.EXIT_ON_CLOSE);
    }

    public final void setIcons(){
        btnAddStudent.setIcon(setImage(getClass().getResource("/IconsUsed/add Student female.png"), btnAddStudent.getWidth(), btnAddStudent.getHeight()));
        btnAddNewBook.setIcon(setImage(getClass().getResource("/IconsUsed/AddBook2.png"), btnAddNewBook.getWidth(), btnAddNewBook.getHeight()));
        btnStatistics.setIcon(setImage(getClass().getResource("/IconsUsed/statistics.jpg"), btnStatistics.getWidth(), btnStatistics.getHeight()));
        btnIssueBook.setIcon(setImage(getClass().getResource("/IconsUsed/Issue Book.png"), btnIssueBook.getWidth(), btnIssueBook.getHeight()));
        btnReturnBook.setIcon(setImage(getClass().getResource("/IconsUsed/Icons made by a href=httpswww.flaticon.comauthorsfreepik title=FreepikFreepika from a href=httpswww.flaticon.com title=Flaticon www.flaticon.coma.png"), btnReturnBook.getWidth(), btnReturnBook.getHeight()));
        btnAllInformation.setIcon(setImage(getClass().getResource("/IconsUsed/All_Information.jpg"), btnAllInformation.getWidth(), btnAllInformation.getHeight()));
    }
    
    public static void connection() throws SQLException, ClassNotFoundException{
        Class.forName("com.mysql.cj.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost/lms", "root", "03468942392");
        //IBACCNFLibrary
    }
    
    public static ImageIcon setImage(java.net.URL imgPath, int width, int height){
        ImageIcon ic = new ImageIcon(imgPath);
        Image image = ic.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
        ImageIcon readyImage = new ImageIcon(image);
        return readyImage;
    }
    public static ImageIcon setImage(String imgPath, int width, int height){
        ImageIcon ic = new ImageIcon(imgPath);
        Image img = ic.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
        return new ImageIcon(img);
    }
    public static ImageIcon setImage(byte[] imgPath, int width, int height){
        ImageIcon ic = new ImageIcon(imgPath);
        Image img = ic.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
        return new ImageIcon(img);
    }
    
    public static String focusLostLogic(String txtFieldString, String hint) {
        if (txtFieldString.equals("")) {
            txtFieldString = hint;
        }
        return txtFieldString;
    }

    public static String focusGainedLogic(String txtFieldString, String hint) {
        if (txtFieldString.equals(hint)) {
            txtFieldString = "";
        }
        return txtFieldString;
    }
    
    protected final void CreateDatabases(){
        //CREATING LMS DATABASE AND ITS TABLES...
        try {
            connection();
            ps = con.prepareStatement("USE LMS");
            if (ps.execute())
                JOptionPane.showMessageDialog(null, "Using Database Failed", "Creating Tables", JOptionPane.ERROR_MESSAGE);
            //CREATING BOOK TABLE.
            ps = con.prepareStatement("CREATE TABLE LMS.BOOK(\n" +
                    "ID VARCHAR(45) NOT NULL,\n" +
                    "Title VARCHAR(300) NOT NULL,\n" +
                    "Author VARCHAR(300) NOT NULL,\n" +
                    "`Subject` VARCHAR(300) NULL,\n" +
                    "Publisher VARCHAR(300) NULL,\n" +
                    "Edition INT NULL,\n" +
                    "`Language` VARCHAR(300) NOT NULL,\n" +
                    "Price INT NULL,\n" +
                    "Currency VARCHAR(45) NULL,\n" +
                    "Place VARCHAR(300) NULL,\n" +
                    "Pages INT NULL,\n" +
                    "Keyword VARCHAR(300) NULL,\n" +
                    "ISBN VARCHAR(300) NULL,\n" +
                    "`Group` VARCHAR(300) NULL,\n" +
                    "PRIMARY KEY (`ID`))");
            if (ps.execute())
                JOptionPane.showMessageDialog(null, "Table Book Creation Failed", "Creating Tables", JOptionPane.ERROR_MESSAGE);

            //CREATING BOOK ISSUE TABLE...
            ps = con.prepareStatement("CREATE TABLE ISSUE_BOOK(\n" +
                                    "BOOK_ID VARCHAR(45) NOT NULL,\n" +
                                    "STUDENT_ID VARCHAR(45) NOT NULL,\n" +
                                    "ISSUE_DATE DATE NULL,\n" +
                                    "RETURN_DATE DATE NULL,\n" +
                                    "BOOK_GROUP VARCHAR(500) NULL,\n" +
                                    "STUDENT_GROUP VARCHAR(500) NULL,\n" +
                                    "PRIMARY KEY (`BOOK_ID`, `STUDENT_ID`))");
            if (ps.execute())
                JOptionPane.showMessageDialog(null, "Table IssueBook Creation Failed", "Creat Table", JOptionPane.ERROR_MESSAGE);

            //CREATING HISTORY TABLE...
            ps = con.prepareStatement("CREATE TABLE History(\n" +
                            "ID INT NOT NULL AUTO_INCREMENT,\n" +
                            "Student_ID VARCHAR(45) NOT NULL,\n" +
                            "Student_Name VARCHAR(300) NOT NULL,\n" +
                            "Book_ID VARCHAR(45) NOT NULL,\n" +
                            "Book_Name VARCHAR(300) NOT NULL,\n" +
                            "Issue_Date DATE NOT NULL,\n" +
                            "Return_Date DATE NOT NULL,\n" +
                            "PRIMARY KEY (`ID`))");
            if (ps.execute())
                JOptionPane.showMessageDialog(null, "Table History Creation Failed", "Creat Table", JOptionPane.ERROR_MESSAGE);
            
            
            //CREATING STUDENT_DATA TABLE
            ps = con.prepareStatement("CREATE TABLE `student_data`(\n" +
                    "`ID` varchar(45) not null,\n" +
                    "`First_Name` varchar(100) not null,\n" +
                    "`Last_Name` varchar(100) not null,\n" +
                    "`Father_Name` varchar(100) null,\n" +
                    "`Sex` varchar(20) null,\n" +
                    "`Phone` varchar(45) null,\n" +
                    "`Date_of_Birth` varchar(45) null,\n" +
                    "`Address` varchar(500) not null,\n" +
                    "`Image` longblob null,\n" +
                    "primary key (`ID`))");
            if (ps.execute())
                JOptionPane.showMessageDialog(null, "Table Student_data Creation Failed", "Creat Table", JOptionPane.ERROR_MESSAGE);
            
            //CREATING ACADEMY TABLE
            ps = con.prepareStatement("CREATE TABLE `Academy`(\n" +
                        "`ID` int not null auto_increment,\n" +
                        "`Academy` varchar(200) not null,\n" +
                        "primary key(`id`))");
            if (ps.execute())
                JOptionPane.showMessageDialog(null, "Table Academy Creation Failed", "Creat Table", JOptionPane.ERROR_MESSAGE);
            
            //CREATING PASSWORD TABLE...
            ps = con.prepareStatement("CREATE TABLE `password`(\n" +
                    "`ID` int not null auto_increment,\n" +
                    "`Password` varchar(200) null ,\n" +
                    "`Email` varchar(200) null,\n" +
                    "`Question` varchar(200) null,\n" +
                    "`Answer` varchar(200) null,\n" +
                    "`Status` varchar(20) null,\n" +
                    "primary key (`id`))");
            if (ps.execute())
                JOptionPane.showMessageDialog(null, "Table password Creation Failed", "Creat Table", JOptionPane.ERROR_MESSAGE);

        } catch (SQLException | ClassNotFoundException ex) {
            //System.out.println(ex);
        }
    }
    
    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        btnAddStudent = new javax.swing.JButton();
        btnAddNewBook = new javax.swing.JButton();
        btnStatistics = new javax.swing.JButton();
        lblAddStudent = new javax.swing.JLabel();
        lblAddBook = new javax.swing.JLabel();
        lblStatistics = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        btnIssueBook = new javax.swing.JButton();
        btnReturnBook = new javax.swing.JButton();
        btnAllInformation = new javax.swing.JButton();
        lblAllInformation = new javax.swing.JLabel();
        lblReturnBook = new javax.swing.JLabel();
        lblIssueBook = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("LMS");

        jPanel1.setBackground(new java.awt.Color(153, 153, 153));

        jPanel3.setBackground(new java.awt.Color(204, 204, 204));
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Operations", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 18), new java.awt.Color(51, 51, 255))); // NOI18N

        btnAddStudent.setBackground(new java.awt.Color(204, 204, 204));
        btnAddStudent.setToolTipText("Add Student");
        btnAddStudent.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnAddStudent.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddStudentActionPerformed(evt);
            }
        });

        btnAddNewBook.setBackground(new java.awt.Color(204, 204, 204));
        btnAddNewBook.setToolTipText("Add New Book");
        btnAddNewBook.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnAddNewBook.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddNewBookActionPerformed(evt);
            }
        });

        btnStatistics.setBackground(new java.awt.Color(204, 204, 204));
        btnStatistics.setToolTipText("Statistics");
        btnStatistics.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnStatistics.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStatisticsActionPerformed(evt);
            }
        });

        lblAddStudent.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblAddStudent.setText("Add Student");
        lblAddStudent.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblAddStudentMouseClicked(evt);
            }
        });

        lblAddBook.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblAddBook.setText("Add Book");
        lblAddBook.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblAddBookMouseClicked(evt);
            }
        });

        lblStatistics.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblStatistics.setText("Statistics");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addComponent(btnAddStudent, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(55, 55, 55)
                        .addComponent(lblAddStudent)))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(62, 62, 62)
                        .addComponent(btnAddNewBook, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(54, 54, 54)
                        .addComponent(btnStatistics, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(93, 93, 93)
                        .addComponent(lblAddBook)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblStatistics)
                        .addGap(78, 78, 78))))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnAddStudent, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnAddNewBook, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnStatistics, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblAddStudent)
                        .addComponent(lblStatistics))
                    .addComponent(lblAddBook))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel4.setBackground(new java.awt.Color(204, 204, 204));
        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Actions", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 18), new java.awt.Color(51, 51, 255))); // NOI18N

        btnIssueBook.setBackground(new java.awt.Color(204, 204, 204));
        btnIssueBook.setToolTipText("Issue Book");
        btnIssueBook.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnIssueBook.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIssueBookActionPerformed(evt);
            }
        });

        btnReturnBook.setBackground(new java.awt.Color(204, 204, 204));
        btnReturnBook.setToolTipText("Return Book");
        btnReturnBook.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnReturnBook.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReturnBookActionPerformed(evt);
            }
        });

        btnAllInformation.setBackground(new java.awt.Color(204, 204, 204));
        btnAllInformation.setMnemonic('A');
        btnAllInformation.setToolTipText("All Information");
        btnAllInformation.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnAllInformation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAllInformationActionPerformed(evt);
            }
        });

        lblAllInformation.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblAllInformation.setText("All Information");

        lblReturnBook.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblReturnBook.setText("Return Book");

        lblIssueBook.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblIssueBook.setText("Issue Book");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addComponent(btnIssueBook, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(59, 59, 59)
                        .addComponent(btnReturnBook, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(62, 62, 62))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(60, 60, 60)
                        .addComponent(lblIssueBook)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblReturnBook)
                        .addGap(85, 85, 85)))
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(btnAllInformation, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 18, Short.MAX_VALUE)
                        .addComponent(lblAllInformation)
                        .addGap(53, 53, 53))))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnIssueBook, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnReturnBook, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAllInformation, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblAllInformation)
                    .addComponent(lblReturnBook)
                    .addComponent(lblIssueBook))
                .addGap(0, 10, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(24, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        jMenu1.setText("File");

        jMenuItem1.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        jMenuItem1.setText("Settings");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem1);

        jMenuItem2.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_H, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        jMenuItem2.setText("History");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem2);

        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnAddStudentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddStudentActionPerformed
        new Add_Student().setVisible(true);
    }//GEN-LAST:event_btnAddStudentActionPerformed

    private void lblAddStudentMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblAddStudentMouseClicked
        new Add_Student().setVisible(true);
    }//GEN-LAST:event_lblAddStudentMouseClicked

    private void btnAddNewBookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddNewBookActionPerformed
        new Add_Book().setVisible(true);
    }//GEN-LAST:event_btnAddNewBookActionPerformed

    private void lblAddBookMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblAddBookMouseClicked
        new Add_Book().setVisible(true);
    }//GEN-LAST:event_lblAddBookMouseClicked

    private void btnIssueBookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIssueBookActionPerformed
       new IssueBook().setVisible(true);
    }//GEN-LAST:event_btnIssueBookActionPerformed

    private void btnStatisticsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStatisticsActionPerformed
        new Statistics().setVisible(true);
    }//GEN-LAST:event_btnStatisticsActionPerformed

    private void btnReturnBookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReturnBookActionPerformed
        new ReturnBooks().setVisible(true);
    }//GEN-LAST:event_btnReturnBookActionPerformed

    private void btnAllInformationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAllInformationActionPerformed
        new All_Information().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnAllInformationActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        new History().setVisible(true);
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        new Settings().setVisible(true);
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainForm().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAddNewBook;
    private javax.swing.JButton btnAddStudent;
    private javax.swing.JButton btnAllInformation;
    private javax.swing.JButton btnIssueBook;
    private javax.swing.JButton btnReturnBook;
    private javax.swing.JButton btnStatistics;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JLabel lblAddBook;
    private javax.swing.JLabel lblAddStudent;
    private javax.swing.JLabel lblAllInformation;
    private javax.swing.JLabel lblIssueBook;
    private javax.swing.JLabel lblReturnBook;
    private javax.swing.JLabel lblStatistics;
    // End of variables declaration//GEN-END:variables

}
