/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EmailPackage;

/**
 *
 * @author Abdul Rehman
 */
public class Test {
    public void test(){
//        String msg = "<h1>Book Issued From IBACCNF Library<br></h1><h2>Today You've Issued following Book \n" +
//" <br>ID: 0004<br>Title: Timeline 3<br> Author: Martin Roberts .</h2>";
//        System.out.println(msg.replaceAll("<br>", "\n").replaceAll("\\<.*?\\>", " "));
        
        String msg = "This <is a> Good boy";

        System.out.println(msg.replaceAll("\\<.*?\\>", "e"));
        
//        System.out.println(msg.replaceAll("\\<.*?\\>", " "));
        
//        msg.replace(msg.indexOf("<"), msg.indexOf(">")+1, "");
        
        System.out.println(msg);
    }
    public static void main(String[] args){
        new Test().test();
    }
}
